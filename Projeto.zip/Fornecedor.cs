using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Globalization;

public class Fornecedor
{
  public int Codigo { get; set; }
  public string Nome { get; set; }
  public string InformacoesContato { get; set; }
  public List<Fornecedor> listaFornecedores;

  public Fornecedor(int codigo, string nome, string informacoesContato)
  {
    Codigo = codigo;
    Nome = nome;
    InformacoesContato = informacoesContato;
    listaFornecedores = new List<Fornecedor>();
  }

  public string ObterInformacoes()
  {
    return ($"Código: {Codigo}, Nome: {Nome}, Contato: {InformacoesContato} ");
  }
  
  public void AdicionarFornecedor(Fornecedor fornecedor)
  {
    listaFornecedores.Add(fornecedor);
    Console.WriteLine($"Fornecedor {fornecedor.Nome} adicionado.");
  }

}