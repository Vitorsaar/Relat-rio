using System;
using System.Collections.Generic;

class Program 
{
  static void Main()
  {
    Estoque estoque = new Estoque();
    RelatorioEstoque relatorio = new RelatorioEstoque();
    Etiqueta etiqueta = new Etiqueta();
    string nomeProduto;
    
    List<Fornecedor> listaFornecedores = new List<Fornecedor>();

    estoque.carregarDados("BancoDeDados/dadosEstoque.txt");

    bool continuar = true;
    while (continuar)
    {
      Console.WriteLine("\n----- Sistema de Gerenciamento de Estoque -----");
      Console.WriteLine("Escolha uma opção:");
      Console.WriteLine("1. Registrar entrada de produto");
      Console.WriteLine("2. Registrar saída de produto");
      Console.WriteLine("3. Verificar produtos com baixa quantidade");
      Console.WriteLine("4. Adicionar novo fornecedor");
      Console.WriteLine("5. Criar etiqueta e imprimir ID");
      Console.WriteLine("6. Gerar relatório HTML");
      Console.WriteLine("7. Exibir informações de um produto");
      Console.WriteLine("8. Cadastrar novo produto");
      Console.WriteLine("9. Listar Fornecedores");
      Console.WriteLine("10. Salvar Dados Estoque");
      Console.WriteLine("0. Sair");

      if (int.TryParse(Console.ReadLine(), out int opcao))
      {
        switch (opcao)
        {
          case 1:
            realizarEntradaEstoque(estoque);
            break;

          case 2:
            registrarSaidaEstoque(estoque);
            break;

          case 3:
            estoque.verificarProdutosBaixaQuantidade();
            break;

          case 4:
            adicionarNovoFornecedor(listaFornecedores);
            break;

          case 5:
            etiqueta.imprimirID();
            break;

          case 6:
            RelatorioEstoque.GerarRelatorioHTML(estoque);
            break;

          case 7:
            Console.Write("\nQual produto deseja ver: ");
            nomeProduto = Console.ReadLine();
            exibirInformacoesProduto(estoque, nomeProduto);
            break;

          case 8:
            cadastrarNovoProduto(estoque);
            break;

          case 9:
            imprimirFornecedores(listaFornecedores);
            break;

          case 10:
            estoque.salvarDados("dadosEstoque.txt");
            Console.WriteLine("Dados salvos com sucesso!");
            break;
          
          case 0:
            Console.WriteLine("\nSaindo do sistema, obrigado.");
            return;

          default:
            Console.WriteLine("Opção inválida, favor tentar novamente.");
            break;
        }
      }
      else
      {
        Console.WriteLine("Entrada inválida. Por favor insira um número.");
      }
    }
  }
  
  static void realizarEntradaEstoque(Estoque estoque)
  {
    Console.Write("\nInforme o código do produto: ");
    int codigoEntrada = int.Parse(Console.ReadLine());

    Console.Write("Informe a quantidade a ser adicionada: ");
    int quantidadeEntrada = int.Parse(Console.ReadLine());

    Produto produtoEntrada = estoque.listaProdutos.Find(p => p.Codigo == codigoEntrada);
    if (produtoEntrada != null)
    {
      estoque.RegistrarEntradaEstoque(produtoEntrada, quantidadeEntrada);
      Console.WriteLine($"Entrada de {quantidadeEntrada} unidades do produto {produtoEntrada.Nome} registrada no estoque.");
    }
    else
    {
      Console.WriteLine("\nProduto não encontrado.");
    }
  }

  static void registrarSaidaEstoque(Estoque estoque)
  {
    Console.Write("\nInforme o código do produto: ");
    int codigoSaida = int.Parse(Console.ReadLine());

    Console.Write("Informe a quantidade a ser retirada: ");
    int quantidadeSaida = int.Parse(Console.ReadLine());

    Produto produtoSaida = estoque.listaProdutos.Find(p => p.Codigo == codigoSaida);

    if (produtoSaida != null)
    {
        if (produtoSaida.QuantidadeEmEstoque >= quantidadeSaida)
        {
          estoque.registrarSaidaEstoque(produtoSaida, quantidadeSaida);
          Console.WriteLine($"Saída de {quantidadeSaida} unidades do produto {produtoSaida.Nome} registrada no estoque.");
        }
        else
        {
          Console.WriteLine($"Quantidade insuficiente de {produtoSaida.Nome} em estoque.");
        }
    }
    
    else
    {
      Console.WriteLine("Produto não encontrado.");
    }
  }
    
  static void adicionarNovoFornecedor(List<Fornecedor> listaFornecedores)
  {    
    Console.Write("\nInforme o código do fornecedor ");
    int codigo = int.Parse(Console.ReadLine());

    Console.Write("Informe o nome do forcenedor: ");
    string nome = Console.ReadLine();

    Console.Write("Informe as informações de contato do fornecedor: ");
    string informacoesContato = Console.ReadLine();

    Fornecedor fornecedor = new Fornecedor(codigo, nome, informacoesContato);
    listaFornecedores.Add(fornecedor);

    Console.Write($"Fornecedor {fornecedor.Nome} adicionado.");
  }

  static void exibirInformacoesProduto(Estoque estoque, string nomeProduto)
  {
    Produto produtoSelecionado = estoque.listaProdutos.Find(p => p.Nome.Equals(nomeProduto,   StringComparison.OrdinalIgnoreCase));
    if (produtoSelecionado != null)
    {
      Console.WriteLine($"\nInformações do produto {produtoSelecionado.Nome}:");
      Console.WriteLine($"Código: {produtoSelecionado.Codigo}.");
      Console.WriteLine($"Preço: {produtoSelecionado.Preco:C}.");
      Console.WriteLine($"Quantidade em estoque: {produtoSelecionado.QuantidadeEmEstoque}.");
    }
    else
    {
      Console.WriteLine("Produto não encontrado.");
    }
  }

  static void imprimirFornecedores(List<Fornecedor> listaFornecedores)
  {
    Console.Write("\nFornecedores cadastrados:");
    foreach (var fornecedor in listaFornecedores)
    {
      Console.Write($"\n---- Código: {fornecedor.Codigo}, Nome: {fornecedor.Nome}, Contato: {fornecedor.InformacoesContato} ----");
    }
  }

  static void cadastrarNovoProduto(Estoque estoque)
  {
      Console.WriteLine("\nCadastrar Novo Produto:");
      Console.Write("\nInforme o código do produto: ");
      if (int.TryParse(Console.ReadLine(), out int codigoProduto))
      {
          Console.Write("Informe o nome do produto: ");
          string nomeProduto = Console.ReadLine();

          Console.Write("Informe o preço do produto: ");
          if (decimal.TryParse(Console.ReadLine(), out decimal precoProduto))
          {
              Console.Write("Informe a quantidade inicial do produto: ");
              if (int.TryParse(Console.ReadLine(), out int quantidadeProduto))
              {
                  Produto novoProduto = new Produto(codigoProduto, nomeProduto, precoProduto, quantidadeProduto);
                  estoque.AdicionarProduto(novoProduto);

                  Console.WriteLine($"Novo produto {nomeProduto} cadastrado e adicionado ao estoque.");
              }
              else
              {
                  Console.WriteLine("\nQuantidade inválida. Por favor insira um número.");
              }
          }
          else
          {
              Console.WriteLine("\nPreço inválido. Por favor insira um número decimal.");
          }
      }
      else
      {
          Console.WriteLine("\nCódigo inválido. Por favor insira um número.");
      }
  } 

}