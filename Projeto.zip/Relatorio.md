# Relatório de Evolução do Projeto

## Data: 14/11/2023: Entrega das classes, atributos e métodos;

## Data: 21/11/2023: Definição do funcionamento do Sistema, separação de tarefas e preparação dos campos do projeto. 

## Data: 28/11/2023: Criação de duas novas classes, classe Etiqueta e Fornecedor, juntamente foram criados novos metódos.

## Data: 30/11/2023: Criação das Classes Produto e Estoque, criação do Menu principal.

## Data: 01/12/2023: Melhorias no menu, métodos e construtores de todas as classes. Criação do sistema para geração de Relatórios em HTML.

## Data: 02/12/2023: Melhorias no main, ajustes nas classes e correção de erros.

## Data: 04/12/2023: Correção de bugs, melhorias na Main e na classe Estoque/Fornecedor. Criação de novos métodos para geração de relatório, informações de produtos e criação de fornecedores. 

## Data: 05/12/2023: Criação do BancoDeDados em txt, funções para carregar e salvar dados. Melhorias no menu e adição de novos cases (Cadastrar produto e listar fornecedores). Correção de bugs na geração do dadosEstoque.txt. Testes das funções do sistema.

## Link vídeo: https://drive.google.com/file/d/1TBzFtBk3uWA8f6lvTFufxR2PGBsTC1L1/view?usp=drive_link


# OBS.: CADA PARTE CONSTRUÍDA E ATUALIZADA DO CÓDIGO FOI FEITA EM "Call" NO DISCORD e/ou em Aula, ESTÁVAMOS JUNTOS EM CADA MOMENTO EM QUE ALTERAMOS E CONSTRUÍMOS O CÓDIGO. Não foi possível apresentar totalmente o sistema em apenas 6 minutos, optamos por resumir algumas partes do sistema, priorizar apenas algumas opções do MENU e estender o vídeo até 10 minutos. Peço compreensão.