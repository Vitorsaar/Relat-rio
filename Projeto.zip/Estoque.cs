using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Globalization;

public class Estoque 
{
  public List<Produto> listaProdutos{ get; set; } 
  public List<string> movimentacaoEstoque { get; set; } 
  
  public Estoque() 
  {
    listaProdutos = new List<Produto>(); 
    movimentacaoEstoque = new List<string>(); 
  }

  public void RegistrarEntradaEstoque(Produto produto, int quantidade) 
  {
    produto.AdicionarProduto(quantidade); 
    movimentacaoEstoque.Add($"Entrada de {quantidade} unidades do produto {produto.Nome} no estoque."); 
  }

  public void registrarSaidaEstoque(Produto produto, int quantidade) 
  {
    produto.AtualizarEstoque(quantidade);
    movimentacaoEstoque.Add($"Saída de {quantidade} unidades do produto {produto.Nome} no estoque.");
  }
  
  public List<Produto> verificarProdutosBaixaQuantidade() 
  {
    List<Produto> produtosBaixaQuantidade = listaProdutos
      .Where(produto => produto.QuantidadeEmEstoque < 10)
      .ToList(); 

    if (produtosBaixaQuantidade.Any()) 
    {
      Console.WriteLine("\nAlerta: Produtos com quantidade baixa em estoque");
      foreach (var produto in produtosBaixaQuantidade)
      {
        Console.WriteLine($"{produto.Nome} - Quantidade: {produto.QuantidadeEmEstoque} unidades.");
      }
    }
    else
    {
      Console.WriteLine("\nNenhum produto em baixa quantidade!");
    }
    return produtosBaixaQuantidade; 
  }

  public void AdicionarProduto(Produto produto)
  {
    listaProdutos.Add(produto);
    Console.WriteLine($"\nNovo produto {produto.Nome} adicionado ao estoque.");
  }

  public void carregarDados(string caminhoArquivo)
  {
    try
    {
      string caminhoCompleto = Path.Combine("BancoDeDados", caminhoArquivo);

      if (File.Exists("BancoDeDados/dadosEstoque.txt"))
      {
        listaProdutos.Clear();

        using (StreamReader sr = new StreamReader("BancoDeDados/dadosEstoque.txt"))
        {
          string linha;
          while ((linha = sr.ReadLine()) != null)
          {
            string[] dadosProduto = linha.Split(';');

            if (dadosProduto.Length == 4)
            {
              int codigo = int.Parse(dadosProduto[0]);
              string nome = dadosProduto[1];
              decimal preco = decimal.Parse(dadosProduto[2]);
              int quantidade = int.Parse(dadosProduto[3]);

              Produto produto = new Produto(codigo, nome, preco, quantidade);
              listaProdutos.Add(produto);
            }
          }
        }

        Console.WriteLine("Dados carregados com sucesso.");
      }
      else
      {
        Console.WriteLine("Arquivo não encontrado. Criado novo arquivo.");
      }
    }
    catch (Exception ex)
    {
      Console.WriteLine($"Erro ao carregar dados: {ex.Message}");
    }
  }

  public void salvarDados(string caminhoArquivo)
  {
    try
    {
      string caminhoCompleto = Path.Combine("BancoDeDados", caminhoArquivo);

      using (StreamWriter sw = new StreamWriter("BancoDeDados/dadosEstoque.txt"))
      {
        foreach (var produto in listaProdutos)
        {
          sw.WriteLine($"{produto.Codigo};{produto.Nome};{produto.Preco};{produto.QuantidadeEmEstoque}");
        }
      }

      Console.WriteLine("Dados salvos com sucesso.");
    }
    catch (Exception ex)
    {
      Console.WriteLine($"Erro ao salvar dados: {ex.Message}");
    }
  }
}
