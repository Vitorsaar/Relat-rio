using System;
using System.IO;
using System.Text;

public class RelatorioEstoque
{
  public static void GerarRelatorioHTML(Estoque estoque)
  {
    StringBuilder htmlBuilder = new StringBuilder();

    htmlBuilder.AppendLine("<html>");
    htmlBuilder.AppendLine("<head><title>Relatório de Estoque</title></head>");
    htmlBuilder.AppendLine("<body>");

    htmlBuilder.AppendLine("<h1>Relatório de Estoque</h1>");

    htmlBuilder.AppendLine("<h2>Produtos em Estoque</h2>");
    foreach (var produto in estoque.listaProdutos)
      {
        htmlBuilder.AppendLine($"<p>Código: {produto.Codigo}, Nome: {produto.Nome}, Quantidade:    {produto.QuantidadeEmEstoque}</p>");
      }

    htmlBuilder.AppendLine("<h2>Movimentação de Estoque</h2>");
    foreach (var movimentacao in estoque.movimentacaoEstoque)
      {
        htmlBuilder.AppendLine($"<p>{movimentacao}</p>");
      }
    
    htmlBuilder.AppendLine("</body>");
    htmlBuilder.AppendLine("</html>");

    File.WriteAllText("RelatorioEstoque.html", htmlBuilder.ToString());

    Console.WriteLine("\nRelatório gerado com sucesso em RelatorioEstoque.html");
  }

  public void ImprimirProdutosEmEstoque(Estoque estoque)
  {
    Console.WriteLine("Produtos em Estoque:");
    foreach (var produto in estoque.listaProdutos)
    {
      Console.WriteLine($"{produto.Nome}: {produto.QuantidadeEmEstoque} unidades");
    }
  }
}