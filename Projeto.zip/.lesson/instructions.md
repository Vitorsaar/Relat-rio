# AED I - Projeto 2 da Disciplina  

  O projeto da disciplina AED I deverá ser realizado dentro deste ambiente de programação, seguindo as instruções detalhadas na Especificação do Projeto, disponível na página da disciplina (Plataforma ESO).

Lembre-se de atualizar os dos arquivos de textos:
  1. Sistema.md: Conterá a descrição detalhado do problema tratado, e da solução desenhada. 
  2. Relatorio.md: Conterá os relatórios semanais de avanço dos trabalhos.

  