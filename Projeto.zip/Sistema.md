# TEMA: Sistema de Gerenciamento de Estoque

# Descrição do Sistema:

O projeto "Sistema de Gestão de Estoque" foi desenvolvido com o próposito de atender às necessidades de empresas que não possuem um sistema eficiente de controle de estoque. Este sistema foi concebido para gerenciar de maneira eficaz os lotes de produtos na empresa.

Classes:
0. Program:
 + Métodos: realizarEntradaEstoque, registrarSaidaEstoque, adicionarNovoFornecedor, exibirInformacoesProduto, imprimirFornecedores, cadastrarNovoProduto.
 
1. Produto:
   + Atributos: Código, Nome, Preço, Quantidade em Estoque.
   + Métodos: AdicionarProduto, AtualizarEstoque.

2. Fornecedor:
   + Atributos: Código, Nome, Informações de Contato.
   + Métodos: AdicionarFornecedor, ObterInformacoes.

3. Estoque:
   + Atributos: listaProdutos (List<Produto>), movimentacaoEstoque.
   + Métodos: RegistrarEntradaEstoque, registrarSaidaEstoque, verificarProdutosBaixaQuantidade, AdicionarProduto, SalvarDados, CarregarDados.

4. Etiqueta:
   + Atributos: ID, Descrição, Preço.
   + Métodos: criarID, atualizarPreço, imprimirID.  

5. RelatórioEstoque
   + Métodos: ImprimirProdutosEmEstoque,movimentacaoEstoque,GerarRelatorioHTML


## Link vídeo: https://drive.google.com/file/d/1TBzFtBk3uWA8f6lvTFufxR2PGBsTC1L1/view?usp=drive_link

# OBS.: CADA PARTE CONSTRUÍDA E ATUALIZADA DO CÓDIGO FOI FEITA EM "Call" NO DISCORD e/ou em Aula, ESTÁVAMOS JUNTOS EM CADA MOMENTO EM QUE ALTERAMOS E CONSTRUÍMOS O CÓDIGO. Não foi possível apresentar totalmente o sistema em apenas 6 minutos, optamos por resumir algumas partes do sistema, priorizar apenas algumas opções do MENU e estender o vídeo até 10 minutos. Peço compreensão.