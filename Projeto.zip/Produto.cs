using System;

public class Produto
{
  public int Codigo { get; set; }
  public string Nome { get; set; }
  public decimal Preco { get; set; }
  public int QuantidadeEmEstoque { get; set; }

  public Produto(int codigo, string nome, decimal preco, int quantidadeEmEstoque)
  {
    Codigo = codigo;
    Nome = nome;
    Preco = preco;
    QuantidadeEmEstoque = quantidadeEmEstoque;
  }

  public void AdicionarProduto(int quantidade)
  {
    QuantidadeEmEstoque += quantidade;
    Console.WriteLine($"\n{quantidade} unidades do produto {Nome} adicionadas ao estoque.");
  }

  public void AtualizarEstoque (int quantidade)
  {
    if (QuantidadeEmEstoque >= quantidade)
      {
        QuantidadeEmEstoque -= quantidade;
        Console.WriteLine($"\n{quantidade} unidades do produto {Nome} removidas do estoque.");
      }
    else
      {
        Console.WriteLine($"Quantidade insuficiente de {Nome} em estoque.");
      }
  }
}