using System;

public class Etiqueta
{
  public int ID {get; set;}
  public string Descricao {get; set;}
  public decimal Preco {get; set;}

  private static readonly Random random = new Random();

  public Etiqueta()
  {
    ID = criarID();
  }
  
  private int criarID()
  {
    return random.Next(1000, 9999);
  }

  public void atualizarPreco(decimal novoPreco)
  {
    Preco = novoPreco;
    Console.WriteLine($"Preco da etiqueta {ID} atualizado para {novoPreco:C}.");
  }

  public void imprimirID()
  {
    Console.WriteLine($"\nID da etiqueta: {ID}.");
  }
}